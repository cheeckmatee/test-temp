// Menu data
const menuData = {
  pizza: [
    { name: "Margherita Pizza", description: "Tomato sauce, mozzarella cheese, fresh union(M: 80 EGP / L: 120 EGP)", image: "items/Margherita.png" }, 
    { name: "Pepperoni Feast", description: "Loaded with pepperoni & melted mozzarella (M: 100 EGP / L: 150 EGP)", image: "items/Pepperoni.png" },
    { name: "BBQ Chicken Supreme", description: "Grilled chicken, BBQ sauce, caramelized onions (M: 110 EGP / L: 160 EGP)", image: "items/BBQ Chicken.png" },
    { name: "Four Cheese Heaven", description: "Mozzarella, Parmesan, Gouda, and Blue Cheese (M: 120 EGP / L: 170 EGP)", image: "items/Four Cheese.png" },
    { name: "Meat Lovers Special", description: "Pepperoni, sausage, beef, smoked turkey (M: 130 EGP / L: 180 EGP)", image: "items/Meat Lovers.png" },
    { name: "Veggie Delight", description: "Bell peppers, mushrooms, olives, tomatoes, onions (M: 90 EGP / L: 140 EGP)", image: "items/Veggie Delight.png" },
    { name: "Seafood Sensation", description: "Shrimp, calamari, tuna, black olives (M: 140 EGP / L: 190 EGP)", image: "items/Spicy Mexican.png" },
    { name: "Spicy Mexican", description: "Jalapeños, spicy beef, cheddar cheese, onions (M: 120 EGP / L: 170 EGP)", image: "items/Seafood.png" }
   
  ],
  extra: [
    { name: "Stuffed Cheese Crust", description: "+40 EGP", image: "items/crust.png" },
    { name: "Extra Pepperoni / Chicken / Shrimp", description: " +30 EGP", image: "items/Shrimp.png" },
    { name: "Extra Cheese / Olives / Mushrooms ", description: " +20 EGP", image: "items/Cheese.png" }
  ],
  sides: [
    { name: "Crispy French Fries", description: "40 EGP", image: "items/fries.png" },
    { name: "Spicy Chicken Wings (6 pcs) ", description: "80 EGP", image: "items/wings.png" },
    { name: "Mozzarella Cheese Sticks (5 pcs) ", description: "70 EGP", image: "items/Mozzarella.png" },
    { name: "Garlic Bread with Cheese ", description: "50 EGP", image: "items/Garlic Bread.png" },
    { name: "Loaded Nachos with Cheese & Salsa", description: "75 EGP", image: "items/Nachos.png" }
  ],
  desserts: [
    { name: "Chocolate Lava Cake", description: "90 EGP", image: "items/lava.png" },
    { name: "Classic Tiramisu", description: "110 EGP", image: "items/Tiramisu.png" }
  ],
  Beverages: [
    { name: "Soft Drinks (Pepsi, 7Up, Mirinda)", description: "25 EGP", image: "items/pepsi.png" },
    { name: "Fresh Orange / Iced Lemon Mint ", description: "45 EGP", image: "items/orange.png" },
    { name: "small water", description: "15 EGP", image: "items/water.png" }
  ]
};

function newFunction() {
  return { name: "Margherita Pizza", description: "Tomato sauce, mozzarella cheese, fresh onion", image: "items/Margherita.png" };
}

// Function to load menu items
function loadMenu(category) {
  const menuGrid = document.getElementById('menu-grid');
  menuGrid.innerHTML = ''; // Clear existing items
  menuData[category].forEach(item => {
    menuGrid.innerHTML += `
      <div class="menu-item">
        <img src="${item.image}" alt="${item.name}">
        <h3>${item.name}</h3>
        <p>${item.description}</p>
      </div>
    `;
  });
}

// Load default category (Burgers)
loadMenu('pizza');

// Add active class to clicked category button and load menu
document.querySelectorAll('.category-btn').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    const category = button.getAttribute('data-category');
    loadMenu(category);
  });
});

// Animated text effect
const animatedText = document.querySelector('.animated-text span');
const words = ["good food", "great taste", "amazing flavors", "delicious bites"];
let currentIndex = 0;

setInterval(() => {
  currentIndex = (currentIndex + 1) % words.length;
  animatedText.textContent = words[currentIndex];
}, 3000); // Change word every 3 seconds

